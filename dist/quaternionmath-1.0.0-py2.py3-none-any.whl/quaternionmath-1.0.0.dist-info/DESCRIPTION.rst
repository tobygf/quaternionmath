
Quaternionmath consists of a "Quaternion" class, which defines the Quaternion
(four-dimensional) numbers. The class provides addition, subtraction,
multiplication, and division logic, as well as string and representation
information.


